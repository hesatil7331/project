function toggleMenu() {
    const nav = document.getElementById("navMenu");
    nav.classList.toggle("show");
}

let touchStartX = 0;
let touchEndX = 0;

const swipeArea = document.getElementById("swipeArea");

swipeArea.addEventListener('touchstart', function(event) {
    touchStartX = event.changedTouches[0].screenX;
}, false);

swipeArea.addEventListener('touchend', function(event) {
    touchEndX = event.changedTouches[0].screenX;
    handleSwipe();
}, false);

function handleSwipe() {
    if (touchEndX < touchStartX - 50) {
        alert("Свайп влево");
    }
    if (touchEndX > touchStartX + 50) {
        alert("Свайп вправо");
    }
}



